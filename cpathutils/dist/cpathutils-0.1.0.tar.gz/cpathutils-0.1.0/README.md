
### build cpath datasets library

```python�

python setup.py bdist_wheel

```
